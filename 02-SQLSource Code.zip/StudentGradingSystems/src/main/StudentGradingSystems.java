package main;

import models.*;

public class StudentGradingSystems {
    public static void main(String[] args) {
     
    }
}
